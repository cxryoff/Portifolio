import React from 'react';
import SectionTitle from './SectionTitle';
import { Calendar, MapPin } from 'lucide-react';

interface Job {
  company: string;
  position: string;
  period: string;
  location: string;
  description: string[];
}

const Experience: React.FC = () => {
  const jobs: Job[] = [
    {
      company: 'EAIfaConnect',
      position: 'Técnico de Telecomunicações',
      period: 'Fev/2022 - Mai/2022',
      location: 'São Paulo, SP',
      description: [
        'Instalação e manutenção de redes de fibra óptica e cabeamento estruturado',
        'Trabalho em equipe para projetos corporativos',
        'Resolução de problemas técnicos em campo'
      ]
    },
    {
      company: 'Grupo Palombo',
      position: 'Auxiliar de Logística',
      period: 'Ago/2022 - Nov/2022',
      location: 'São Paulo, SP',
      description: [
        'Organização e controle logístico de armazém',
        'Gestão de prazos e processos',
        'Apoio operacional à equipe de design gráfico'
      ]
    }
  ];

  return (
    <section id="experience" className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle title="Experiência Profissional" subtitle="Minha trajetória no mercado de trabalho" />
        
        <div className="max-w-4xl mx-auto">
          <div className="relative border-l-4 border-blue-500 dark:border-blue-400 pl-10 space-y-12 ml-6">
            {jobs.map((job, index) => (
              <div 
                key={index}
                className="relative group"
              >
                <div className="absolute -left-[3.25rem] top-0 w-10 h-10 rounded-full bg-blue-500 dark:bg-blue-400 flex items-center justify-center shadow-md z-10">
                  <span className="text-white font-bold">{index + 1}</span>
                </div>
                
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 transition-all duration-300 group-hover:shadow-lg">
                  <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-1">
                        {job.position}
                      </h3>
                      <h4 className="text-lg font-semibold text-blue-600 dark:text-blue-400">
                        {job.company}
                      </h4>
                    </div>
                    
                    <div className="flex flex-col mt-3 md:mt-0 md:items-end">
                      <div className="flex items-center text-gray-600 dark:text-gray-400 mb-1">
                        <Calendar size={18} className="mr-1" />
                        <span>{job.period}</span>
                      </div>
                      <div className="flex items-center text-gray-600 dark:text-gray-400">
                        <MapPin size={18} className="mr-1" />
                        <span>{job.location}</span>
                      </div>
                    </div>
                  </div>
                  
                  <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 space-y-2">
                    {job.description.map((item, i) => (
                      <li key={i}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;